/* 
 * File:   DrawableObject.h
 * Author: stuetzlec
 *
 * Created on October 10, 2017, 3:37 PM
 */

#ifndef DRAWABLEOBJECT_H
#define DRAWABLEOBJECT_H

#include <glm/glm.hpp>
#include "Shader.hpp"
#include "Texture.hpp"


using glm::vec3;

class DrawableObject {
public:

    DrawableObject() {
        model = glm::mat4(1.0f);
    }

    virtual void draw(Shader*) = 0;

    glm::mat4 getModelMatrix() {
        return model;
    }

    void applyTransformation(glm::mat4 t) {
        model = t * model;
    }
    
    virtual void setTexture(Texture*)=0; // added by Pat Langille

    
private:

protected:
    glm::mat4 model;
    Texture* tex;

};

#endif /* DRAWABLEOBJECT_H */
